Provided by Nobiax.

CC0 1.0 Universal (CC0 1.0)
Public Domain Dedication
No Copyright
This license is acceptable for Free Cultural Works
The person who associated a work with this deed has dedicated the work to the public domain by waiving all of his or her rights to the work worldwide under copyright law, including all related and neighboring rights, to the extent allowed by law.


You can copy, modify, distribute and perform the work, even for commercial purposes, all without asking permission.

So absolutely free to use or to modify in any kind of work (personal, commercial or else) =)



Please, don't be an ass, don't just resell it. ><


Please, give me a link of the result at nobiax.deviantart.com or my other account on OpenGameArt.com (yughues) or ShareCG.com (yughues)
( watch my journal on deviantart to find them ) ;)

Or on Youtube.

For any commissions details are on my DeviantArt account.